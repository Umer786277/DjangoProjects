function download(data) {
	document.getElementById("download").innerHTML = "Download Speed: " + data + " Mbit/s";
}
function upload(data) {
	document.getElementById("upload").innerHTML = "Upload Speed: " + data + " Mbit/s";
}