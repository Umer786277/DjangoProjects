from django.contrib import admin
from EDU.models import signup

# Register your models here.
admin.site.register(signup)
