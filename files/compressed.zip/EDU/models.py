from django.db import models

# Create your models here.

class signup(models.Model):
    username=models.CharField(max_length=110)
    email=models.CharField(max_length=50)
    password=models.CharField(max_length=60)
    repassword=models.CharField(max_length=60)