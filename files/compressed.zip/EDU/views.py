from django.shortcuts import render
from django.views.generic import TemplateView



# Create your views here.
def index(request):
    return render(request, 'base.html')

def contact(request):
    return render(request, 'contact.html')

def up(request):
    return render(request, 'signup.html')

def about(request):
    return render(request, 'about.html')



def loog(request):
    return render(request, 'log.html')

def tips(request):
    return render(request, 'tips.html')