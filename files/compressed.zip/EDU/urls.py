from django.contrib import admin
from django.urls import path
from EDU import views
from django.views.generic import TemplateView







urlpatterns =[
    path('admin/', admin.site.urls),
    path('',views.index,name='home'),
    path('contact/',views.contact,name='contact'),
    path('up/',views.up,name='up'),
    path('about/',views.about,name='about'),
    path('loog/',views.loog,name='loog'),
     path('tips/',views.tips,name='tips'),
   # path(r'^contact/',views.contact, name='contact.html'),
    ]
#urlpatterns = ( path('',views.index,name='home'),
 #  '',
  #  url(r'^profile/', TemplateView.as_view(template_name='profile.html'),
   #                   name='profile'),
#)