from django.db import models

# Create your models here.

class MultiStepFormModel(models.Model):
    id=models.AutoField(primary_key=True)
    fname=models.CharField(max_length=255)
    lname=models.CharField(max_length=255)
    phone=models.CharField(max_length=255)
    date=models.DateTimeField(max_length=255,auto_now_add=True)
    airline_name=models.CharField(max_length=255)
    flight_no=models.CharField(max_length=255)
    flight_date=models.DateTimeField(max_length=255,auto_now_add=True)
    
    
    flight_distruption=models.CharField(max_length=255)
    flight_hr=models.CharField(max_length=255)
    flight_days=models.CharField(max_length=255)
    select=models.CharField(max_length=255)
    objects=models.Manager()

    



  #  id=models.AutoField(primary_key=True)
   # fname=models.CharField(max_length=255)
    #lname=models.CharField(max_length=255,null=True)
    #phone=models.CharField(max_length=255,null=True)
   # date=models.DateTimeField(auto_now_add=True)

    
    #airline_name=models.CharField(max_length=255,null=True)
   # flight_no=models.CharField(max_length=255,null=True)
   # flight_date=models.DateTimeField(max_length=255,auto_now_add=True)

   # flight_distruption=models.CharField(max_length=255,null=True)
   # flight_hr=models.CharField(max_length=255,null=True)
    #flight_days=models.CharField(max_length=255,null=True)
    #select=models.CharField(max_length=255,null=True)

    
   