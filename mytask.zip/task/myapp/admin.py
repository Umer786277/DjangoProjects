from django.contrib import admin

# Register your models here.

from.models import MultiStepFormModel

admin.site.register(MultiStepFormModel)
