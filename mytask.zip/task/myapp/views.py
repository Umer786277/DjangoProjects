from django.shortcuts import render,redirect
from.models import MultiStepFormModel

# Create your views here.


def index(request):
     if request.method=="POST":
        fname=request.POST.get("fname")
        lname=request.POST.get("lname")
        phone=request.POST.get("phone")
        date=request.POST.get("created_at")
        airline_name=request.POST.get("airline")
        flight_no=request.POST.get("flight")
        flight_date=request.POST.get("ar_created_at")
        flight_distruption=request.POST.get("flightr")
        flight_hr=request.POST.get("flighthr")
        flight_days=request.POST.get("flightd")
    
        select=request.POST.get("select")
        multistepform=MultiStepFormModel.objects.create(fname=fname,lname=lname,phone=phone,date=date,airline_name=airline_name,flight_no=flight_no,flight_date=flight_date,flight_distruption=flight_distruption,flight_hr=flight_hr,flight_days=flight_days,select=select)
        multistepform.save()
        return redirect('/')
        #if multistepform.is_valid():
         #   comment = multistepform.save(commit=False)
            
          #  comment.save()
           # 
    
     return render(request,'base.html')
    
